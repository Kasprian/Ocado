#Solution for OCADO Intership by Piotr Kasprowicz

App.java - source code
out/zadanie-java.jar - jar file with arguments as for example:
args[0]= /home/pjoter/Downloads/zadanie-java/self-test-data/logic-bomb/store.json
args[1] = /home/pjoter/Downloads/zadanie-java/self-test-data/logic-bomb/orders.json